template
========

This is a template for you to use to get your portfolio started in the course.

There are 3 files to begin this portfolio:
1. An HTML file (index.html), which serves as the homepage for the portfolio.
2. Another HTML file (lived.html), which is linked to the homepage.
3. A CSS file to jazz up the design a bit (No one actually like Times New Roman do they?!!!)
